# Smart Chat (Firebase version)

Yeh ek real, deployable website hai — phone/email OTP login, chat requests, posts, stories, aur reels ke saath. Ise apni website banane ke liye neeche diye steps follow karein.

⚠️ **Important**: Maine yeh code likha hai lekin mere paas is sandbox mein internet access nahi hai, isliye main isko khud run/test nahi kar saka. Aapko apne computer par test karna hoga. Agar koi chhoti error aaye (khaas kar Firebase SDK ke naam/version se), mujhe error message bhej dena, main fix kar dunga.

## Step 1 — Firebase project banayein

1. https://console.firebase.google.com par jaayein, "Add project" karein, naam dein (jaise "smart-chat").
2. Project ke andar **Build → Authentication → Get Started** karein.
   - **Sign-in method** tab mein **Phone** enable karein.
   - Wahi pe **Email link (passwordless sign-in)** wala "Email/Password" provider enable karein aur "Email link" toggle ON karein.
3. **Build → Firestore Database → Create database** karein (production mode).
4. **Build → Storage → Get started** karein (default bucket).
5. Project Settings (gear icon) → General → "Your apps" → **Web app (</>)** add karein. Wahan se aapko config object milega (apiKey, authDomain, etc).

## Step 2 — Is project ko apne computer par set up karein

1. Yeh poora folder apne computer par copy karein (ZIP download karein).
2. `.env.example` ko copy karke `.env` banayein, aur Firebase se mile saare values usme daal dein.
3. Terminal mein:
   ```
   npm install
   npm run dev
   ```
   Ye local par (http://localhost:5173) site khol dega taaki aap test kar saken.

## Step 3 — Phone Auth ke liye zaroori setting

Firebase Phone Auth ke liye **Billing (Blaze plan)** activate karna padta hai agar aap free-tier SMS quota se zyada bhejna chahte hain — lekin shuruaati testing free quota mein ho jaati hai. Console mein **Authentication → Sign-in method → Phone** ke andar apna test number bhi add kar sakte hain jisse real SMS ke bina test ho jaaye.

Console mein **Authentication → Settings → Authorized domains** mein apna deployment domain (jaise `your-app.vercel.app`) zaroor add karein, warna login kaam nahi karega.

## Step 4 — Security Rules deploy karein

Firebase console mein:
- **Firestore Database → Rules** tab mein is repo ki `firestore.rules` file ka content paste karke Publish karein.
- **Storage → Rules** tab mein is repo ki `storage.rules` file ka content paste karke Publish karein.

## Step 5 — Website ko live deploy karein (Vercel — free)

1. https://vercel.com par GitHub se sign up karein.
2. Is project ko ek GitHub repo mein push karein.
3. Vercel mein "Add New Project" → apna repo select karein.
4. Environment Variables mein wahi `.env` wali saari `VITE_FIREBASE_...` values daal dein.
5. Deploy dabayein. Kuch second mein aapko ek live URL mil jaayega (jaise `smart-chat.vercel.app`).
6. Us URL ko wapas Firebase Console → Authentication → Settings → Authorized domains mein add karna na bhoolein.

(Netlify bhi isi tarah kaam karta hai agar Vercel ke bajaye wo use karna ho.)

## Kya-kya real hai ab

- **Phone signup/login** — real numeric OTP SMS ke through
- **Email signup/login** — Firebase email link (aapke email mein click-to-login link aata hai, number wala OTP nahi — yeh Firebase ki apni limitation hai)
- Sabka data (profiles, messages, posts, stories, chat requests) ab Firestore database mein save hota hai — permanently, sabke liye
- Photos Firebase Storage mein upload hoti hain

## Limitations / aage kya karein

- Recaptcha (phone verification ke liye) kabhi kabhi UI mein halka sa dikh sakta hai — chahe to invisible badge hata kar customize kar sakte hain.
- Username search abhi "starts with" type case-insensitive hai, poora fuzzy search nahi.
- Agar app real users ke liye scale karni ho, toh Firestore composite indexes console khud suggest kar dega (ek link deta hai error mein, use click karke enable kar dena).
